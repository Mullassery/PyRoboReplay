PyRoboReplay test fixture placeholder - used by IncidentBundle::from_zip unit tests
